import React, { useState, useEffect } from 'react';
import CandidateOverview from './CandidateOverview';
import CandidateProfile from './CandidateProfile';
import FindJobs from './FindJobs';
import EligibilityCheck from './EligibilityCheck';
import MyApplications from './MyApplications';
import ServiceMarketplace from './ServiceMarketplace';

const CandidateDashboard = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [notifications, setNotifications] = useState([]);
  const [showNotif, setShowNotif] = useState(false);
  const [unread, setUnread] = useState(0);

  useEffect(() => { fetchNotifications(); }, []);

  const fetchNotifications = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('http://localhost:5000/api/notifications', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setNotifications(data.notifications || []);
        setUnread((data.notifications || []).filter(n => !n.IsRead).length);
      }
    } catch (_) {}
  };

  const markAllRead = async () => {
    try {
      const token = localStorage.getItem('token');
      await fetch('http://localhost:5000/api/notifications/read-all', {
        method: 'PUT', headers: { Authorization: `Bearer ${token}` }
      });
      setUnread(0);
      setNotifications(prev => prev.map(n => ({ ...n, IsRead: true })));
    } catch (_) {}
  };

  const navItems = [
    { id: 'overview',      label: 'Dashboard',           emoji: '📊' },
    { id: 'profile',       label: 'My Profile',          emoji: '👤' },
    { id: 'findJobs',      label: 'Find Jobs',           emoji: '🔍' },
    { id: 'eligibility',   label: 'Eligibility Check',   emoji: '✅' },
    { id: 'applications',  label: 'My Applications',     emoji: '📄' },
    { id: 'marketplace',   label: 'Service Marketplace', emoji: '🛍️' },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':     return <CandidateOverview user={user} onNavigate={setActiveTab} />;
      case 'profile':      return <CandidateProfile  user={user} />;
      case 'findJobs':     return <FindJobs          user={user} />;
      case 'eligibility':  return <EligibilityCheck  user={user} />;
      case 'applications': return <MyApplications    user={user} />;
      case 'marketplace':  return <ServiceMarketplace user={user} />;
      default:             return <CandidateOverview user={user} onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="cd-root">
      {/* ── Sidebar ── */}
      <aside className="cd-sidebar">
        <div className="cd-sidebar-logo">
          <div className="cd-logo-mark">H</div>
          <span className="cd-logo-text">Hirely</span>
          <button className="cd-close-sidebar" onClick={() => {}}>✕</button>
        </div>

        <nav className="cd-nav">
          {navItems.map(item => (
            <button
              key={item.id}
              className={`cd-nav-btn ${activeTab === item.id ? 'active' : ''}`}
              onClick={() => setActiveTab(item.id)}
            >
              <span className="cd-nav-icon">{item.emoji}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="cd-sidebar-user">
          <div className="cd-user-avatar">
            {(user?.name || 'C').charAt(0).toUpperCase()}
          </div>
          <div className="cd-user-info">
            <span className="cd-user-name">{user?.name || 'Candidate'}</span>
            <span className="cd-user-sub">Candidate</span>
          </div>
          <button className="cd-logout-ico" onClick={onLogout} title="Logout">⏻</button>
        </div>
      </aside>

      {/* ── Topbar ── */}
      <header className="cd-topbar">
        <span className="cd-topbar-label">
          {navItems.find(n => n.id === activeTab)?.label || 'Dashboard'}
        </span>
        <div className="cd-topbar-right">
          <div className="cd-notif-wrap">
            <button className="cd-notif-btn"
              onClick={() => { setShowNotif(s => !s); if (unread) markAllRead(); }}>
              🔔
              {unread > 0 && <span className="cd-badge">{unread}</span>}
            </button>
            {showNotif && (
              <div className="cd-notif-drop">
                <div className="cd-notif-hdr">Notifications</div>
                {notifications.length === 0
                  ? <div className="cd-notif-empty">No notifications yet</div>
                  : notifications.slice(0, 6).map(n => (
                    <div key={n.NotificationID} className={`cd-notif-row ${!n.IsRead ? 'unread' : ''}`}>
                      <span>{n.Message}</span>
                      <small>{new Date(n.CreatedAt).toLocaleDateString()}</small>
                    </div>
                  ))}
              </div>
            )}
          </div>

          <div className="cd-chip">
            <div className="cd-chip-av">{(user?.name || 'C').charAt(0).toUpperCase()}</div>
            <div>
              <div className="cd-chip-name">{user?.name || 'Candidate'}</div>
              <div className="cd-chip-role">Candidate</div>
            </div>
          </div>

          
        </div>
      </header>

      {/* ── Main ── */}
      <main className="cd-main">
        {renderContent()}
      </main>

      <style>{`
        * { box-sizing: border-box; }
        .cd-root {
          display: flex;
          min-height: 100vh;
          background: #F1F5F9;
          font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        /* Sidebar */
        .cd-sidebar {
          width: 248px;
          background: #fff;
          border-right: 1px solid #E2E8F0;
          display: flex; flex-direction: column;
          position: fixed; top: 0; left: 0; bottom: 0;
          z-index: 200;
        }
        .cd-sidebar-logo {
          display: flex; align-items: center; gap: 10px;
          padding: 20px 18px 16px;
          border-bottom: 1px solid #F1F5F9;
        }
        .cd-logo-mark {
          width: 34px; height: 34px;
          background: linear-gradient(135deg, #667eea );
          border-radius: 8px;
          display: flex; align-items: center; justify-content: center;
          color: #fff; font-weight: 800; font-size: 16px; flex-shrink: 0;
        }
        .cd-logo-text { font-size: 20px; font-weight: 700; color: #0F172A; flex: 1; }
        .cd-close-sidebar { display: none; background: none; border: none; cursor: pointer; color: #94A3B8; }

        .cd-nav {
          flex: 1; padding: 12px 10px;
          display: flex; flex-direction: column; gap: 2px;
          overflow-y: auto;
        }
        .cd-nav-btn {
          display: flex; align-items: center; gap: 12px;
          width: 100%; padding: 11px 14px;
          border: none; background: transparent;
          border-radius: 8px; cursor: pointer;
          font-size: 14px; color: #475569; font-weight: 500;
          transition: all 0.15s; text-align: left;
        }
        .cd-nav-btn:hover { background: #F8FAFC; color: #1E293B; }
        .cd-nav-btn.active { background: #EEF2FF; color: #4338CA; font-weight: 600; }
        .cd-nav-icon { font-size: 16px; width: 22px; text-align: center; }

        .cd-sidebar-user {
          padding: 14px 16px;
          border-top: 1px solid #F1F5F9;
          display: flex; align-items: center; gap: 10px;
        }
        .cd-user-avatar {
          width: 36px; height: 36px;
          background: linear-gradient(135deg, #667eea);
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          color: #fff; font-weight: 700; font-size: 14px; flex-shrink: 0;
        }
        .cd-user-info { flex: 1; overflow: hidden; }
        .cd-user-name { display: block; font-size: 13px; font-weight: 600; color: #1E293B;
          white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .cd-user-sub { display: block; font-size: 11px; color: #94A3B8; }
        .cd-logout-ico {
          background: none; border: none; cursor: pointer;
          color: #94A3B8; font-size: 16px; padding: 4px;
          transition: color 0.15s; border-radius: 6px;
        }
        .cd-logout-ico:hover { color: #EF4444; background: #FFF1F2; }

        /* Topbar */
        .cd-topbar {
          position: fixed; top: 0; left: 248px; right: 0;
          height: 60px; background: #fff;
          border-bottom: 1px solid #E2E8F0;
          display: flex; align-items: center;
          justify-content: space-between;
          padding: 0 28px; z-index: 100;
        }
        .cd-topbar-label { font-size: 15px; font-weight: 600; color: #1E293B; }
        .cd-topbar-right { display: flex; align-items: center; gap: 14px; }

        /* Notifications */
        .cd-notif-wrap { position: relative; }
        .cd-notif-btn {
          position: relative;
          background: none; border: none; cursor: pointer;
          font-size: 18px; padding: 7px; border-radius: 8px;
          transition: background 0.15s;
        }
        .cd-notif-btn:hover { background: #F1F5F9; }
        .cd-badge {
          position: absolute; top: 1px; right: 1px;
          background: #EF4444; color: #fff;
          border-radius: 50%; width: 16px; height: 16px;
          font-size: 10px; font-weight: 700;
          display: flex; align-items: center; justify-content: center;
        }
        .cd-notif-drop {
          position: absolute; top: 44px; right: 0;
          width: 300px; background: #fff;
          border: 1px solid #E2E8F0; border-radius: 12px;
          box-shadow: 0 10px 40px rgba(0,0,0,0.12);
          overflow: hidden; z-index: 999;
        }
        .cd-notif-hdr { padding: 12px 16px; font-weight: 600; font-size: 13px; color: #1E293B; border-bottom: 1px solid #F1F5F9; }
        .cd-notif-empty { padding: 20px 16px; color: #94A3B8; font-size: 13px; text-align: center; }
        .cd-notif-row { padding: 12px 16px; border-bottom: 1px solid #F8FAFC; display: flex; flex-direction: column; gap: 2px; }
        .cd-notif-row.unread { background: #F8FAFF; }
        .cd-notif-row span { font-size: 13px; color: #374151; }
        .cd-notif-row small { font-size: 11px; color: #94A3B8; }

        /* User chip */
        .cd-chip { display: flex; align-items: center; gap: 8px; }
        .cd-chip-av {
          width: 32px; height: 32px;
          background: linear-gradient(135deg, #667eea);
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          color: #fff; font-weight: 700; font-size: 13px;
        }
        .cd-chip-name { font-size: 13px; font-weight: 600; color: #1E293B; }
        .cd-chip-role { font-size: 11px; color: #94A3B8; }

        

        /* Main */
        .cd-main {
          margin-left: 248px; margin-top: 60px;
          padding: 28px; min-height: calc(100vh - 60px);
        }

        @media (max-width: 768px) {
          .cd-sidebar { width: 100%; position: relative; height: auto; }
          .cd-topbar { left: 0; }
          .cd-main { margin-left: 0; padding: 16px; }
        }
      `}</style>
    </div>
  );
};

export default CandidateDashboard;