import React, { useState, useEffect } from 'react';

const ViewApplicants = ({ user, jobId, onBack }) => {
  const [applicants, setApplicants] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (jobId) {
      fetchApplicants();
    }
  }, [jobId]);

  const fetchApplicants = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:5000/api/jobs/${jobId}/applicants`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      if (data.success) {
        setApplicants(data.applicants || []);
      }
    } catch (error) {
      console.error('Error fetching applicants:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (applicationId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      await fetch('http://localhost:5000/api/applications/status', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ applicationId, status: newStatus })
      });
      fetchApplicants();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'Pending': { bg: '#FEF3C7', text: '#92400E', border: '#FCD34D' },
      'Shortlisted': { bg: '#DBEAFE', text: '#1E40AF', border: '#93C5FD' },
      'Interview': { bg: '#EDE9FE', text: '#5B21B6', border: '#C4B5FD' },
      'Accepted': { bg: '#D1FAE5', text: '#065F46', border: '#6EE7B7' },
      'Rejected': { bg: '#FEE2E2', text: '#991B1B', border: '#FCA5A5' }
    };
    return colors[status] || { bg: '#F3F4F6', text: '#374151', border: '#D1D5DB' };
  };

  const getInitials = (name) => {
    if (!name) return '?';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  if (loading) return (
    <div className="loading-state">
      <div className="spinner"></div>
      <p>Loading applicants...</p>
    </div>
  );

  return (
    <div className="applicants-page">
      <div className="page-header">
        <button className="back-btn" onClick={onBack}>
          ← Back to Jobs
        </button>
        <div>
          <h1>Job Applicants</h1>
          <p className="subtitle">
            {applicants.length} applicant(s) for this position
          </p>
        </div>
      </div>
      
      {applicants.length === 0 ? (
        <div className="empty-state">
          <span>👥</span>
          <h3>No applicants yet</h3>
          <p>When candidates apply for this job, they will appear here</p>
        </div>
      ) : (
        <div className="applicants-grid">
          {applicants.map(app => {
            const statusStyle = getStatusColor(app.Status);
            return (
              <div key={app.ApplicationID} className="applicant-card">
                <div className="applicant-header">
                  <div className="avatar">
                    {getInitials(app.Name)}
                  </div>
                  <div className="applicant-info">
                    <h3>{app.Name || 'Unknown Candidate'}</h3>
                    <p className="email">{app.Email}</p>
                    {app.Phone && <p className="phone">📱 {app.Phone}</p>}
                  </div>
                </div>
                
                <div className="applicant-details">
                  {app.Education && (
                    <div className="detail-item">
                      <span>🎓</span>
                      <div>
                        <small>Education</small>
                        <p>{app.Education}</p>
                      </div>
                    </div>
                  )}
                  
                  {app.Experience && (
                    <div className="detail-item">
                      <span>💼</span>
                      <div>
                        <small>Experience</small>
                        <p>{app.Experience}</p>
                      </div>
                    </div>
                  )}
                  
                  {app.CVPath && (
                    <div className="detail-item">
                      <span>📄</span>
                      <div>
                        <small>CV</small>
                        <a href={app.CVPath} target="_blank" rel="noopener noreferrer" className="cv-link">
                          View CV
                        </a>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="applicant-footer">
                  <span className="date-info">
                    📅 Applied: {new Date(app.AppliedDate).toLocaleDateString('en-US', {
                      year: 'numeric', month: 'short', day: 'numeric'
                    })}
                  </span>
                  
                  <select 
                    value={app.Status}
                    onChange={(e) => updateStatus(app.ApplicationID, e.target.value)}
                    style={{ borderColor: statusStyle.border }}
                    className="status-select"
                  >
                    <option value="Pending">⏳ Pending</option>
                    <option value="Shortlisted">⭐ Shortlisted</option>
                    <option value="Interview">📅 Interview</option>
                    <option value="Accepted">✅ Accepted</option>
                    <option value="Rejected">❌ Rejected</option>
                  </select>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <style>{`
        .applicants-page { max-width: 1100px; }
        
        .page-header {
          display: flex;
          align-items: center;
          gap: 20px;
          margin-bottom: 30px;
        }
        
        .back-btn {
          padding: 10px 20px;
          border: 2px solid #E5E7EB;
          background: white;
          border-radius: 10px;
          cursor: pointer;
          font-size: 14px;
          color: #374151;
          transition: all 0.2s;
        }
        
        .back-btn:hover {
          border-color: #667EEA;
          color: #667EEA;
          background: #EEF2FF;
        }
        
        .page-header h1 { font-size: 28px; color: #111827; margin: 0 0 5px 0; }
        .subtitle { color: #6B7280; margin: 0; font-size: 15px; }
        
        .applicants-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(450px, 1fr));
          gap: 20px;
        }
        
        .empty-state {
          text-align: center;
          padding: 80px 20px;
          background: white;
          border-radius: 16px;
          box-shadow: 0 1px 3px rgba(0,0,0,0.06);
        }
        
        .empty-state span { font-size: 64px; display: block; margin-bottom: 16px; }
        .empty-state h3 { color: #111827; margin-bottom: 8px; }
        .empty-state p { color: #6B7280; }
        
        .applicant-card {
          background: white;
          border-radius: 16px;
          padding: 24px;
          box-shadow: 0 1px 3px rgba(0,0,0,0.06);
          transition: all 0.2s;
        }
        
        .applicant-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.08);
        }
        
        .applicant-header {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 16px;
        }
        
        .avatar {
          width: 48px;
          height: 48px;
          background: linear-gradient(135deg, #667EEA, #764BA2);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 18px;
          font-weight: 600;
          flex-shrink: 0;
        }
        
        .applicant-info h3 { margin: 0; font-size: 16px; color: #111827; }
        .applicant-info .email { margin: 4px 0; color: #6B7280; font-size: 13px; }
        .applicant-info .phone { margin: 0; color: #9CA3AF; font-size: 13px; }
        
        .applicant-details {
          background: #F9FAFB;
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 16px;
        }
        
        .detail-item {
          display: flex;
          gap: 12px;
          margin-bottom: 12px;
          align-items: flex-start;
        }
        
        .detail-item:last-child { margin-bottom: 0; }
        .detail-item span { font-size: 18px; flex-shrink: 0; }
        .detail-item small { color: #9CA3AF; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; }
        .detail-item p { margin: 2px 0 0 0; color: #374151; font-size: 14px; }
        
        .cv-link { color: #667EEA; text-decoration: none; font-size: 14px; font-weight: 500; }
        .cv-link:hover { text-decoration: underline; }
        
        .applicant-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-top: 16px;
          border-top: 1px solid #F3F4F6;
        }
        
        .date-info { color: #9CA3AF; font-size: 13px; }
        
        .status-select {
          padding: 8px 14px;
          border: 2px solid #E5E7EB;
          border-radius: 8px;
          font-size: 13px;
          background: white;
          cursor: pointer;
          font-weight: 500;
        }
        
        .status-select:focus { outline: none; }
        
        .loading-state { text-align: center; padding: 80px; }
        
        .spinner {
          width: 40px; height: 40px;
          border: 3px solid #F3F4F6;
          border-top-color: #667EEA;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
          margin: 0 auto 16px;
        }
        
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default ViewApplicants;