import React, { useState, useEffect } from 'react';

const EmployerProfile = ({ user, companyData, onUpdate }) => {
  const [formData, setFormData] = useState({
    companyName: '',
    description: '',
    contactDetails: '',
    portfolio: '',
    services: '',
    products: ''
  });
  const [logo, setLogo] = useState(null);
  const [banner, setBanner] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (companyData) {
      setFormData({
        companyName: companyData.companyName || '',
        description: companyData.description || '',
        contactDetails: companyData.contactDetails || '',
        portfolio: companyData.portfolio || '',
        services: companyData.services || '',
        products: companyData.products || ''
      });
    }
  }, [companyData]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/company/update-profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });

      const data = await response.json();
      if (data.success) {
        setMessage('✅ Profile updated successfully!');
        if (onUpdate) onUpdate();
      } else {
        setMessage('❌ ' + data.message);
      }
    } catch (error) {
      setMessage('❌ Error updating profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="profile-page">
      <h1>Company Profile</h1>
      <p className="subtitle">Manage your company information visible to candidates</p>
      
      {message && <div className="message">{message}</div>}
      
      <form onSubmit={handleSubmit} className="profile-form">
        <div className="form-group">
          <label>Company Name *</label>
          <input
            type="text"
            name="companyName"
            value={formData.companyName}
            onChange={handleChange}
            required
            placeholder="Enter company name"
          />
        </div>
        
        <div className="form-group">
          <label>Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows="4"
            placeholder="Describe your company..."
          />
        </div>
        
        <div className="form-group">
          <label>Contact Details</label>
          <input
            type="text"
            name="contactDetails"
            value={formData.contactDetails}
            onChange={handleChange}
            placeholder="Email, phone, address..."
          />
        </div>
        
        <div className="form-group">
          <label>Portfolio / Website</label>
          <input
            type="url"
            name="portfolio"
            value={formData.portfolio}
            onChange={handleChange}
            placeholder="https://your-company.com"
          />
        </div>
        
        <div className="form-row">
          <div className="form-group">
            <label>Services Offered</label>
            <textarea
              name="services"
              value={formData.services}
              onChange={handleChange}
              rows="3"
              placeholder="List your services (comma separated)..."
            />
          </div>
          
          <div className="form-group">
            <label>Products</label>
            <textarea
              name="products"
              value={formData.products}
              onChange={handleChange}
              rows="3"
              placeholder="List your products (comma separated)..."
            />
          </div>
        </div>
        
        <button type="submit" className="save-btn" disabled={loading}>
          {loading ? 'Saving...' : '💾 Save Changes'}
        </button>
      </form>

      <style>{`
        .profile-page {
          max-width: 800px;
        }
        
        .profile-page h1 {
          color: #333;
          margin-bottom: 5px;
        }
        
        .subtitle {
          color: #666;
          margin-bottom: 30px;
        }
        
        .message {
          padding: 12px;
          border-radius: 8px;
          margin-bottom: 20px;
          background: #f0f9ff;
          border: 1px solid #bae6fd;
        }
        
        .profile-form {
          background: white;
          padding: 30px;
          border-radius: 15px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .form-group {
          margin-bottom: 20px;
        }
        
        .form-group label {
          display: block;
          margin-bottom: 8px;
          font-weight: 600;
          color: #333;
        }
        
        .form-group input,
        .form-group textarea {
          width: 100%;
          padding: 12px;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          font-size: 14px;
          transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
          outline: none;
          border-color: #667eea;
        }
        
        .form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
        }
        
        .save-btn {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          padding: 14px 30px;
          border-radius: 8px;
          font-size: 16px;
          cursor: pointer;
          transition: transform 0.3s;
        }
        
        .save-btn:hover {
          transform: translateY(-2px);
        }
      `}</style>
    </div>
  );
};

export default EmployerProfile;