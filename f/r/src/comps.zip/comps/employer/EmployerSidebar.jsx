import React from 'react';

const EmployerSidebar = ({ activeTab, setActiveTab, user, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'profile', label: 'Company Profile', icon: '🏢' },
    { id: 'post-job', label: 'Post Job', icon: '📝' },
    { id: 'manage-jobs', label: 'Manage Jobs', icon: '📋' },
    { id: 'applicants', label: 'View Applicants', icon: '👥' },
    { id: 'services', label: 'Services', icon: '🔧' },
    { id: 'products', label: 'Products', icon: '📦' },
  ];

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h2>Hirely</h2>
        <p>Employer Portal</p>
      </div>
      
      <div className="user-info">
        <div className="user-avatar">
          {user.name?.charAt(0).toUpperCase()}
        </div>
        <div>
          <strong>{user.name}</strong>
          <p>{user.email}</p>
        </div>
      </div>
      
      <nav className="sidebar-nav">
        {menuItems.map(item => (
          <button
            key={item.id}
            className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
            onClick={() => setActiveTab(item.id)}
          >
            <span className="nav-icon">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
      
      <button className="logout-btn" onClick={onLogout}>
        🚪 Logout
      </button>

      <style>{`
        .sidebar {
          width: 250px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 30px 20px;
          display: flex;
          flex-direction: column;
          position: fixed;
          height: 100vh;
          left: 0;
          top: 0;
          overflow-y: auto;
          overflow-x: hidden;
          z-index: 1000;
        }
        
        .sidebar::-webkit-scrollbar {
          width: 6px;
        }
        
        .sidebar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
        
        .sidebar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.3);
          border-radius: 10px;
        }
        
        .sidebar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.5);
        }
        
        .sidebar-header {
          text-align: center;
          padding-bottom: 30px;
          border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        
        .sidebar-header h2 {
          font-size: 28px;
          margin-bottom: 5px;
        }
        
        .sidebar-header p {
          margin: 0;
          opacity: 0.8;
        }
        
        .user-info {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 20px 0;
          border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        
        .user-avatar {
          width: 40px;
          height: 40px;
          background: rgba(255,255,255,0.3);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 18px;
          flex-shrink: 0;
        }
        
        .user-info p {
          font-size: 12px;
          opacity: 0.8;
          margin: 0;
        }
        
        .sidebar-nav {
          flex: 1;
          padding: 20px 0;
          display: flex;
          flex-direction: column;
          gap: 5px;
          overflow-y: auto;
          min-height: 0;
        }
        
        .nav-item {
          width: 100%;
          padding: 12px 15px;
          background: transparent;
          border: none;
          color: white;
          cursor: pointer;
          border-radius: 8px;
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 14px;
          transition: background 0.3s;
          text-align: left;
          flex-shrink: 0;
        }
        
        .nav-item:hover {
          background: rgba(255,255,255,0.2);
        }
        
        .nav-item.active {
          background: rgba(255,255,255,0.3);
        }
        
        .nav-icon {
          font-size: 18px;
          width: 24px;
          text-align: center;
        }
        
        .logout-btn {
          width: 100%;
          padding: 12px;
          background: rgba(255,255,255,0.1);
          border: 1px solid rgba(255,255,255,0.3);
          color: white;
          border-radius: 8px;
          cursor: pointer;
          font-size: 14px;
          transition: background 0.3s;
          margin-top: 10px;
          flex-shrink: 0;
        }
        
        .logout-btn:hover {
          background: rgba(255,59,48,0.8);
          border-color: transparent;
        }
      `}</style>
    </div>
  );
};

export default EmployerSidebar;