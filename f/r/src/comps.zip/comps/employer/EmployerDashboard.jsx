import React, { useState, useEffect } from 'react';
import EmployerSidebar from './EmployerSidebar';
import EmployerProfile from './EmployerProfile';
import PostJob from './PostJob';
import ManageJobs from './ManageJobs';
import ViewApplicants from './ViewApplicants';
import ManageServices from './ManageServices';
import ManageProducts from './ManageProducts';

const EmployerDashboard = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [companyData, setCompanyData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchCompanyProfile = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/company/profile', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      if (data.success) {
        setCompanyData(data.data);
      }
    } catch (error) {
      console.error('Error fetching company profile:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCompanyProfile();
  }, []);

  const stats = {
    activeJobs: companyData?.activeJobs || 0,
    totalApplicants: companyData?.totalApplicants || 0,
    servicesOffered: companyData?.servicesCount || 0,
    productsListed: companyData?.productsCount || 0
  };

  return (
    <div className="employer-layout">
      <EmployerSidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        user={user}
        onLogout={onLogout}
      />
      
      <div className="employer-content">
        {activeTab === 'dashboard' && (
          <div className="dashboard-page">
            <h1>Welcome back, {user.name}! 👋</h1>
            <p className="subtitle">{companyData?.CompanyName || 'Your Company Dashboard'}</p>
            
            <div className="stats-grid">
              <div className="stat-card purple">
                <div className="stat-icon">📋</div>
                <div className="stat-info">
                  <h3>{stats.activeJobs}</h3>
                  <p>Active Jobs</p>
                </div>
              </div>
              
              <div className="stat-card blue">
                <div className="stat-icon">👥</div>
                <div className="stat-info">
                  <h3>{stats.totalApplicants}</h3>
                  <p>Total Applicants</p>
                </div>
              </div>
              
              <div className="stat-card green">
                <div className="stat-icon">🔧</div>
                <div className="stat-info">
                  <h3>{stats.servicesOffered}</h3>
                  <p>Services</p>
                </div>
              </div>
              
              <div className="stat-card orange">
                <div className="stat-icon">📦</div>
                <div className="stat-info">
                  <h3>{stats.productsListed}</h3>
                  <p>Products</p>
                </div>
              </div>
            </div>

            <div className="quick-actions">
              <h2>Quick Actions</h2>
              <div className="actions-grid">
                <button onClick={() => setActiveTab('post-job')} className="action-btn">
                  <span>📝</span> Post New Job
                </button>
                <button onClick={() => setActiveTab('manage-jobs')} className="action-btn">
                  <span>📊</span> Manage Jobs
                </button>
                <button onClick={() => setActiveTab('services')} className="action-btn">
                  <span>🔧</span> Add Services
                </button>
                <button onClick={() => setActiveTab('profile')} className="action-btn">
                  <span>⚙️</span> Company Profile
                </button>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'profile' && (
          <EmployerProfile 
            user={user}
            companyData={companyData}
            onUpdate={fetchCompanyProfile}
          />
        )}
        
        {activeTab === 'post-job' && (
          <PostJob 
            user={user}
            onJobPosted={() => setActiveTab('manage-jobs')}
          />
        )}
        
        {activeTab === 'manage-jobs' && (
          <ManageJobs 
            user={user}
            onViewApplicants={(jobId) => {
              localStorage.setItem('selectedJobId', jobId);
              setActiveTab('applicants');
            }}
          />
        )}
        
        {activeTab === 'applicants' && (
          <ViewApplicants 
            user={user}
            jobId={localStorage.getItem('selectedJobId')}
          />
        )}
        
        {activeTab === 'services' && (
          <ManageServices user={user} />
        )}
        
        {activeTab === 'products' && (
          <ManageProducts user={user} />
        )}
      </div>

      <style>{`
        .employer-layout {
          display: flex;
          min-height: 100vh;
          background: #f5f6fa;
        }
        
        .employer-content {
          flex: 1;
          padding: 30px;
          margin-left: 250px;
        }
        
        .dashboard-page h1 {
          font-size: 28px;
          color: #333;
          margin-bottom: 5px;
        }
        
        .subtitle {
          color: #666;
          margin-bottom: 30px;
        }
        
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 20px;
          margin-bottom: 40px;
        }
        
        .stat-card {
          background: white;
          padding: 25px;
          border-radius: 15px;
          display: flex;
          align-items: center;
          gap: 15px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .stat-icon {
          font-size: 40px;
        }
        
        .stat-info h3 {
          font-size: 28px;
          color: #333;
        }
        
        .stat-info p {
          color: #666;
          font-size: 14px;
        }
        
        .stat-card.purple { border-left: 4px solid #667eea; }
        .stat-card.blue { border-left: 4px solid #4facfe; }
        .stat-card.green { border-left: 4px solid #43e97b; }
        .stat-card.orange { border-left: 4px solid #fa709a; }
        
        .quick-actions h2 {
          margin-bottom: 20px;
          color: #333;
        }
        
        .actions-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 15px;
        }
        
        .action-btn {
          background: white;
          border: none;
          padding: 20px;
          border-radius: 12px;
          cursor: pointer;
          font-size: 16px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.05);
          transition: all 0.3s;
        }
        
        .action-btn:hover {
          transform: translateY(-3px);
          box-shadow: 0 5px 20px rgba(102, 126, 234, 0.2);
        }
        
        .action-btn span {
          font-size: 30px;
        }
        
        @media (max-width: 1024px) {
          .stats-grid, .actions-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }
      `}</style>
    </div>
  );
};

export default EmployerDashboard;